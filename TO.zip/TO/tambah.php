<?php include 'config.php'; ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Tambah Barang</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f9f9f9; padding: 20px; }
        h2 { color: #333; }
        form { background: white; padding: 20px; max-width: 400px; margin: auto; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
        input[type=text], input[type=number], input[type=date] {
            width: 100%; padding: 8px; margin-bottom: 10px; border-radius: 4px; border: 1px solid #ccc;
        }
        button {
            background-color: #007bff; color: white; padding: 10px 20px; border: none;
            border-radius: 4px; cursor: pointer;
        }
        button:hover { background-color: #0056b3; }
    </style>
</head>
<body>
    <h2 align="center">Tambah Barang</h2>
    <form method="POST" action="simpan.php">
        Nama: <input type="text" name="nama" required><br>
        Jumlah: <input type="number" name="jumlah" required><br>
        Harga: <input type="number" name="harga" required><br>
        Jenis: <input type="text" name="jenis" required><br>
        Tanggal Masuk: <input type="date" name="tgl" required><br>
        <button type="submit">Simpan</button>
    </form>
</body>
</html>
