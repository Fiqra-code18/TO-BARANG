<?php include 'config.php'; ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Barang</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f4f4f4; padding: 20px; }
        h2 { color: #333; }
        a.button, .btn {
            display: inline-block; padding: 8px 12px; border-radius: 4px;
            text-decoration: none; font-size: 14px; margin: 2px;
        }
        a.button { background-color: #28a745; color: white; margin-bottom: 10px; }
        .btn-edit { background-color: #ffc107; color: white; }
        .btn-hapus { background-color: #dc3545; color: white; }
        table { width: 100%; border-collapse: collapse; background-color: white; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
        th, td { padding: 10px; text-align: left; border-bottom: 1px solid #ddd; }
        th { background-color: #007bff; color: white; }
        tr:hover { background-color: #f1f1f1; }
        form { margin-bottom: 15px; }
        input[type="text"], select {
            padding: 5px; font-size: 14px; margin-right: 5px;
        }
        input[type="submit"] {
            padding: 6px 12px; font-size: 14px;
        }
    </style>
</head>
<body>
    <h2>Daftar Barang</h2>
    <a class="button" href="tambah.php">+ Tambah Barang</a>

    <form method="GET" action="">
        <input type="text" name="search" placeholder="Cari nama barang..." value="<?= isset($_GET['search']) ? htmlspecialchars($_GET['search']) : '' ?>">
        <select name="jenis">
            <option value="">Semua Jenis</option>
            <option value="0" <?= (isset($_GET['jenis']) && $_GET['jenis'] === '0') ? 'selected' : '' ?>>Elektronik</option>
            <option value="1" <?= (isset($_GET['jenis']) && $_GET['jenis'] === '1') ? 'selected' : '' ?>>Furniture</option>
            <option value="2" <?= (isset($_GET['jenis']) && $_GET['jenis'] === '2') ? 'selected' : '' ?>>Alat Tulis</option>
        </select>
        <input type="submit" value="Cari">
    </form>

    <table>
        <tr>
            <th>No</th>
            <th>Nama</th>
            <th>Jumlah</th>
            <th>Harga</th>
            <th>Jenis</th>
            <th>Tanggal Masuk</th>
            <th>Aksi</th>
        </tr>
        <?php
        $jenis_map = [
            0 => 'Elektronik',
            1 => 'Furniture',
            2 => 'Alat Tulis'
        ];

        // Proses pencarian dan filter
        $where = [];
        if (!empty($_GET['search'])) {
            $search = $conn->real_escape_string($_GET['search']);
            $where[] = "nama LIKE '%$search%'";
        }
        if (isset($_GET['jenis']) && $_GET['jenis'] !== '') {
            $jenis = intval($_GET['jenis']);
            $where[] = "jenis = $jenis";
        }

        $sql = "SELECT * FROM barang";
        if (!empty($where)) {
            $sql .= " WHERE " . implode(" AND ", $where);
        }

        $result = $conn->query($sql);
        $no = 1;
        while ($row = $result->fetch_assoc()):
        ?>
        <tr>
            <td><?= $no++ ?></td>
            <td><?= htmlspecialchars($row['nama']) ?></td>
            <td><?= $row['jumlah'] ?></td>
            <td><?= $row['harga'] ?></td>
            <td><?= isset($jenis_map[$row['jenis']]) ? $jenis_map[$row['jenis']] : 'Tidak Diketahui' ?></td>
            <td><?= $row['tgl'] ?></td>
            <td>
                <a class="btn btn-edit" href="edit.php?id=<?= $row['id'] ?>">Edit</a>
                <a class="btn btn-hapus" href="hapus.php?id=<?= $row['id'] ?>" onclick="return confirm('Yakin ingin menghapus?')">Hapus</a>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
</body>
</html>
