<?php
include 'config.php';
$id = $_GET['id'];
$data = $conn->query("SELECT * FROM barang WHERE id=$id")->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Edit Barang</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f9f9f9; padding: 20px; }
        h2 { color: #333; }
        form { background: white; padding: 20px; max-width: 400px; margin: auto; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
        input[type=text], input[type=number], input[type=date] {
            width: 100%; padding: 8px; margin-bottom: 10px; border-radius: 4px; border: 1px solid #ccc;
        }
        button {
            background-color: #ffc107; color: black; padding: 10px 20px; border: none;
            border-radius: 4px; cursor: pointer;
        }
        button:hover { background-color: #e0a800; }
    </style>
</head>
<body>
    <h2 align="center">Edit Barang</h2>
    <form method="POST" action="update.php">
        <input type="hidden" name="id" value="<?= $data['id'] ?>">
        Nama: <input type="text" name="nama" value="<?= $data['nama'] ?>" required><br>
        Jumlah: <input type="number" name="jumlah" value="<?= $data['jumlah'] ?>" required><br>
        Harga: <input type="number" name="harga" value="<?= $data['harga'] ?>" required><br>
        Jenis: <select name="jenis" required>
    <option value="0" <?= ($data['jenis'] == 0) ? 'selected' : '' ?>>Elektronik</option>
    <option value="1" <?= ($data['jenis'] == 1) ? 'selected' : '' ?>>Furniture</option>
    <option value="2" <?= ($data['jenis'] == 2) ? 'selected' : '' ?>>Alat Tulis</option>
</select>
 <required><br>
        Tanggal Masuk: <input type="date" name="tgl" value="<?= $data['tgl'] ?>" required><br>
        <button type="submit">Update</button>
    </form>
</body>
</html>
