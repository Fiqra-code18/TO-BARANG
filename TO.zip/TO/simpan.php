<?php
include 'config.php';

$sql = "INSERT INTO barang (nama, jumlah, harga, jenis, tgl) VALUES (?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);

// Cek jika prepare() gagal
if (!$stmt) {
    die("Prepare failed: (" . $conn->errno . ") " . $conn->error);
}

$stmt->bind_param("siiis", $_POST['nama'], $_POST['jumlah'], $_POST['harga'], $_POST['jenis'], $_POST['tgl']);
$stmt->execute();

header('Location: index.php');
exit;
?>
