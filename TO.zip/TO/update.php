<?php
include 'config.php';
$sql = "UPDATE barang SET nama=?, jumlah=?, harga=?, jenis=?, tgl=? WHERE id=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("siiisi", $_POST['nama'], $_POST['jumlah'], $_POST['harga'], $_POST['jenis'], $_POST['tgl'], $_POST['id']);
$stmt->execute();
header('Location: index.php');
?>
